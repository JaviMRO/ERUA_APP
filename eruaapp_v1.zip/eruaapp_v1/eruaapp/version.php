<?php
defined('MOODLE_INTERNAL') || die();

$plugin->component = 'local_eruaapp';
$plugin->version   = 2024120100; // YYYYMMDDxx
$plugin->requires  = 2022041900; // Requiere Moodle 4.0+
$plugin->maturity  = MATURITY_ALPHA;
$plugin->release   = 'v1.0';