<?php
/**
 * @package local_eruaapp
 * @copyright 2024 Su Nombre/Organización
 * @license http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace local_eruaapp\external;

use external_api;
use external_function_parameters;
use external_value;
use external_single_structure;
use core_user;
use context_system;

defined('MOODLE_INTERNAL') || die();

/**
 * Clase de servicios externos (Web Services) para el plugin local_eruaapp.
 * * Esta clase contiene todos los métodos accesibles a través de la API de Moodle 
 * (tanto para AJAX interno como para servicios externos REST/SOAP), 
 * manejando la lógica de negocio para el feed social.
 * * @since Moodle 4.x
 */
class eruaapp_external extends external_api {

    /**
     * Define los parámetros esperados para la función get_posts.
     * * @return external_function_parameters La definición de los parámetros.
     */
    public static function get_posts_parameters() {
        return new external_function_parameters(
            array(
                'skip' => new external_value(
                    PARAM_INT, 
                    'Número de posts a saltar (offset para paginación).', 
                    VALUE_DEFAULT, 
                    0
                ),
                'limit' => new external_value(
                    PARAM_INT, 
                    'Número máximo de posts a devolver.', 
                    VALUE_DEFAULT, 
                    10
                ),
            )
        );
    }

    /**
     * Obtiene una lista paginada de posts del feed social de ERUA App.
     * * Realiza una consulta JOIN para obtener el conteo de likes y verifica si el usuario 
     * actual ha dado like a cada post.
     * * @param int $skip Número de posts a saltar (offset).
     * @param int $limit Número máximo de posts a devolver.
     * @return array Array de objetos de posts, enriquecidos y listos para Mustache.
     * @throws \moodle_exception Si la capacidad de visualización no se cumple.
     */
    public static function get_posts($skip = 0, $limit = 10) {
        global $DB, $USER;

        // 1. Validar contexto y permisos (capacidad de ver el feed).
        $context = context_system::instance();
        self::validate_context($context);
        require_capability('local/eruaapp:viewfeed', $context);
        
        // 2. Validar parámetros.
        $params = self::validate_parameters(self::get_posts_parameters(), [
            'skip' => $skip, 
            'limit' => $limit
        ]);

        $skip = $params['skip'];
        $limit = $params['limit'];

        // 3. Consulta a la base de datos (conteo de likes incluido).
        $sql = "SELECT p.*, count(l.id) AS numlikes 
                FROM {local_erua_posts} p
                LEFT JOIN {local_erua_likes} l ON l.postid = p.id
                GROUP BY p.id
                ORDER BY p.timecreated DESC";
        
        $posts = $DB->get_records_sql($sql, null, $skip, $limit);

        $results = [];

        // 4. Formatear y enriquecer los datos para el frontend.
        foreach ($posts as $post) {
            $post = (array) $post; 

            // Obtener información del usuario Moodle (autor del post).
            $user = core_user::get_user($post['userid']);
            
            // Verificar si el usuario actual ha dado like.
            $liked = $DB->record_exists('local_erua_likes', [
                'postid' => $post['id'],
                'userid' => $USER->id
            ]);
            
            // Preparar las banderas para la lógica de Mustache.
            $is_blog = ($post['type'] == 'blog');
            $is_photo = ($post['type'] == 'photo');

            $results[] = [
                'id' => $post['id'],
                'content' => $post['content'],
                'type' => $post['type'],
                'title' => $post['title'],
                'attachment' => $post['attachment'],
                'official_org' => $post['official_org'],
                
                // Información del autor y del post.
                'fullname' => $user->firstname . ' ' . $user->lastname,
                'userpictureurl' => core_user::get_user_picture_url($user),
                'timecreated_str' => userdate($post['timecreated'], get_string('strftimerecentfull', 'local_eruaapp')),
                
                // Interacción.
                'numlikes' => (int)$post['numlikes'], // Aseguramos que sea INT.
                'numcomments' => 0, 
                'liked' => $liked, 
                
                // Banderas para Mustache.
                'is_blog' => $is_blog,
                'is_photo' => $is_photo,
                'readtime' => 5, // Valor fijo de ejemplo.
            ];
        }

        return $results;
    }

    /**
     * Define la estructura de datos que devuelve la función get_posts.
     * * La definición estricta es obligatoria para los servicios externos.
     * * @return external_single_structure
     */
    public static function get_posts_returns() {
        return new external_single_structure(
            array(
                'id' => new external_value(PARAM_INT, 'ID del post.'),
                'content' => new external_value(PARAM_TEXT, 'Contenido del post.'),
                'type' => new external_value(PARAM_ALPHANUMEXT, 'Tipo de post (status, blog, photo, official).'),
                'title' => new external_value(PARAM_TEXT, 'Título del post (si es tipo blog).', VALUE_OPTIONAL),
                'attachment' => new external_value(PARAM_TEXT, 'URL de la imagen o archivo adjunto.', VALUE_OPTIONAL),
                'official_org' => new external_value(PARAM_TEXT, 'Nombre de la organización oficial.', VALUE_OPTIONAL),
                'fullname' => new external_value(PARAM_TEXT, 'Nombre completo del autor.'),
                'userpictureurl' => new external_value(PARAM_URL, 'URL de la imagen del perfil del autor.'),
                'timecreated_str' => new external_value(PARAM_TEXT, 'Fecha de creación formateada (ej: 2h ago).'),
                'numlikes' => new external_value(PARAM_INT, 'Número total de likes del post.'),
                'numcomments' => new external_value(PARAM_INT, 'Número total de comentarios.'),
                'liked' => new external_value(PARAM_BOOL, 'Indica si el usuario actual ha dado like al post.'),
                'is_blog' => new external_value(PARAM_BOOL, 'Bandera para el template Mustache (tipo blog).'),
                'is_photo' => new external_value(PARAM_BOOL, 'Bandera para el template Mustache (tipo photo).'),
                'readtime' => new external_value(PARAM_INT, 'Tiempo de lectura estimado (para tipo blog).'),
            )
        );
    }
}