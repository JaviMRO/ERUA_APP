/**
 * Main Javascript module for local_eruaapp (Master v9)
 */
define(['jquery', 'core/ajax', 'core/templates', 'core/notification'], function($, Ajax, Templates, Notification) {

    // --- 1. MEMORIA DE DATOS (Simulación de Base de Datos) ---
    
    // Chats separados
    var chatData = {
        'Sofi Tsolova': [
            { type: 'received', text: "How's the magazine article coming along?" }
        ],
        'Alexandra Petrova': [
            { type: 'received', text: "Hi! I saw you are from ULPGC. Can we connect?" }
        ]
    };

    // Comentarios separados por Post
    var postsData = {
        'post_sophie': {
            comments: [
                { user: 'Maria_23', text: 'Great initiative! 👏👏', time: '2h ago' }
            ],
            countId: 'count-post_sophie'
        },
        'post_javier': {
            comments: [],
            countId: 'count-post_javier'
        }
        // Los nuevos posts se añadirán aquí dinámicamente
    };

    // Estado actual
    var currentChatUser = null;
    var currentPostId = null;

    // --- 2. FUNCIONES DE LÓGICA ---

    var renderMessages = function(userName) {
        var list = $('#chat-messages');
        list.empty();
        var messages = chatData[userName] || [];
        
        messages.forEach(function(msg) {
            if(msg.type === 'received') {
                list.append(`
                    <div class="flex gap-2 max-w-[80%] scale-in">
                        <div class="w-8 h-8 rounded-full bg-alliance-accent/30 flex-shrink-0 mt-auto"></div>
                        <div class="bg-white p-3 rounded-2xl rounded-bl-none shadow-sm text-sm text-gray-800 border border-gray-100">
                            ${msg.text}
                        </div>
                    </div>`);
            } else {
                list.append(`
                    <div class="flex gap-2 max-w-[80%] ml-auto justify-end scale-in">
                        <div class="bg-alliance-primary p-3 rounded-2xl rounded-br-none shadow-md text-sm text-white">
                            ${msg.text}
                        </div>
                    </div>`);
            }
        });
        // Scroll al fondo
        list.scrollTop(list[0].scrollHeight);
    };

    var renderComments = function(postId) {
        var list = $('#comments-list');
        list.empty();
        var data = postsData[postId];
        
        if (!data || data.comments.length === 0) {
            list.html('<div class="text-center text-gray-400 mt-10 text-sm">No comments yet. Be the first!</div>');
        } else {
            data.comments.forEach(function(c) {
                list.append(`
                    <div class="flex gap-3 mb-4 scale-in">
                         <div class="w-8 h-8 rounded-full bg-gray-200 flex-shrink-0"></div>
                         <div>
                             <p class="text-sm"><span class="font-bold mr-1">${c.user}</span>${c.text}</p>
                             <span class="text-xs text-gray-400">${c.time}</span>
                         </div>
                    </div>`);
            });
        }
    };

    var showToast = function(message) {
        var toast = $('#toast');
        $('#toast-message').text(message);
        toast.removeClass('hidden toast-exit').addClass('toast-enter');
        setTimeout(function() {
            toast.removeClass('toast-enter').addClass('toast-exit');
            setTimeout(function() { toast.addClass('hidden'); }, 500);
        }, 3000);
    };

    return {
        init: function() {
            var self = this;
            console.log('ERUA App v9 initialized');

            // --- DELEGACIÓN DE EVENTOS (El corazón del sistema) ---
            // Usamos $('body').on(...) para que funcione también con elementos creados dinámicamente

            // 1. Navegación Principal (Tabs)
            $('body').on('click', '.nav-btn', function(e) {
                e.preventDefault();
                var target = $(this).data('target');
                $('.view-section').addClass('hidden'); // Ocultar todo
                $('#view-' + target).removeClass('hidden'); // Mostrar target
                
                // Actualizar botones
                $('.nav-btn').removeClass('nav-active text-alliance-primary').addClass('text-gray-400');
                $('.nav-btn[data-target="' + target + '"]').removeClass('text-gray-400').addClass('nav-active text-alliance-primary');
                
                // Header Titles
                var titles = { 'home': 'ERUA APP', 'search': 'EXPLORAR', 'messages': 'MENSAJES', 'profile': 'MI PERFIL', 'notifications': 'ACTIVIDAD' };
                $('#header-title').text(titles[target]);
            });

            // 2. Abrir Modales (Chat, Comentarios, Upload)
            $('body').on('click', '[data-action="toggle-upload"]', function() {
                $('#upload-modal').toggleClass('hidden');
            });

            $('body').on('click', '[data-action="open-creator"]', function() {
                var type = $(this).data('type'); // create-blog o create-photo
                $('#upload-modal').addClass('hidden');
                $('.view-section').addClass('hidden');
                $('#view-' + type).removeClass('hidden');
                $('#bottom-nav, #main-header').addClass('hidden');
            });

            $('body').on('click', '[data-action="open-chat"]', function() {
                var user = $(this).data('user');
                currentChatUser = user;
                $('#chat-user-name').text(user);
                
                // Resetear estado visual si venía de una notificación
                $(this).find('p').removeClass('font-bold text-alliance-primary').addClass('text-gray-500');
                $(this).find('span').removeClass('text-alliance-primary').addClass('text-gray-400');

                $('#view-chat-conversation').removeClass('hidden');
                $('#bottom-nav, #main-header').addClass('hidden');
                renderMessages(user);
            });

            $('body').on('click', '[onclick^="openComments"]', function(e) {
                // Capturamos el evento onclick del HTML antiguo y lo gestionamos aquí
                e.preventDefault();
                // Extraemos el ID del post de la función: openComments('post_id')
                var onclickVal = $(this).attr('onclick'); 
                var postId = onclickVal.match(/'([^']+)'/)[1];
                
                currentPostId = postId;
                $('#view-comments').removeClass('hidden');
                $('#bottom-nav, #main-header').addClass('hidden');
                renderComments(postId);
            });

            // 3. Acciones de Cierre (Back buttons)
            $('body').on('click', '[data-action="cancel-creation"]', function() {
                $('.view-section').addClass('hidden');
                $('#view-home').removeClass('hidden');
                $('#bottom-nav, #main-header').removeClass('hidden');
            });

            $('body').on('click', '[data-action="close-chat"], [data-action="close-comments"], [data-action="close-article"]', function() {
                $(this).closest('.view-section').addClass('hidden'); // Ocultar el modal actual
                $('#bottom-nav, #main-header').removeClass('hidden'); // Mostrar nav
            });

            // 4. Lógica de Negocio (Publicar, Comentar, Enviar)
            
            // Publicar Comentario
            $('body').on('click', '[data-action="post-comment"]', function() {
                var input = $('#comment-input');
                var text = input.val();
                if(!text.trim()) return;

                if (!postsData[currentPostId]) {
                    postsData[currentPostId] = { comments: [], countId: null };
                }
                postsData[currentPostId].comments.push({ user: 'Me', text: text, time: 'Just now' });
                
                renderComments(currentPostId);
                input.val('');

                // Actualizar contador visualmente
                var countId = postsData[currentPostId].countId;
                if(countId) {
                    var span = $('#' + countId);
                    span.text(parseInt(span.text()) + 1);
                }
            });

            // Enviar Mensaje
            $('body').on('click', '[data-action="send-message"]', function() {
                var input = $('#chat-input');
                var text = input.val();
                if(!text.trim()) return;

                chatData[currentChatUser].push({ type: 'sent', text: text });
                renderMessages(currentChatUser);
                input.val('');

                // Simular respuesta IA
                $('#chat-status').html('<span class="text-alliance-primary">typing...</span>');
                setTimeout(function() {
                    $('#chat-status').html('<span class="text-green-500 flex items-center gap-1">● Online</span>');
                    var replies = ["Sounds great!", "Let me check.", "Awesome! 👏"];
                    var reply = replies[Math.floor(Math.random() * replies.length)];
                    chatData[currentChatUser].push({ type: 'received', text: reply });
                    renderMessages(currentChatUser);
                }, 2500);
            });

            // Publicar Post
            $('body').on('click', '[data-action="publish-blog"]', function() {
                var title = $('#blog-title').val();
                var body = $('#blog-body').val();
                if(!title) return;

                var newId = 'post_' + new Date().getTime();
                postsData[newId] = { comments: [], countId: 'count-' + newId };

                var html = `
                <article class="bg-white mb-5 rounded-xl border border-gray-100 shadow-sm overflow-hidden p-5 relative scale-in">
                    <span class="absolute top-4 right-4 text-gray-200 material-icons text-4xl transform rotate-12">article</span>
                    <div class="flex items-center mb-4">
                        <div class="w-10 h-10 rounded-full bg-alliance-primary flex items-center justify-center text-white font-bold">ME</div>
                        <div class="ml-3"><span class="font-bold text-sm block text-gray-900">Javier Martín</span><span class="text-xs text-gray-500">ULPGC • Just now</span></div>
                    </div>
                    <div class="mb-2"><h3 class="font-bold text-lg text-alliance-primary mb-2 leading-tight">${title}</h3><p class="text-sm text-gray-600">${body}</p></div>
                    <div class="flex gap-4 mt-3 items-center">
                        <button class="group flex items-center gap-1"><span class="material-icons text-gray-400 text-sm">favorite_border</span><span class="text-xs text-gray-500">0</span></button>
                        <button onclick="openComments('${newId}')" class="flex items-center gap-1"><span class="material-icons text-gray-400 text-sm">mode_comment</span><span id="count-${newId}" class="text-xs text-gray-500 font-medium">0</span></button>
                    </div>
                </article>`;
                
                $('#new-posts-container').prepend(html);
                
                // Reset y salir
                $('#blog-title').val(''); $('#blog-body').val('');
                $('.view-section').addClass('hidden');
                $('#view-home').removeClass('hidden');
                $('#bottom-nav, #main-header').removeClass('hidden');
                showToast("Blog published!");
            });
            
            // Aceptar Solicitud (Follow logic)
            $('body').on('click', '[data-action="accept-follow"]', function() {
                $(this).text('Following').removeClass('bg-alliance-action text-white').addClass('bg-gray-200 text-gray-600');
                var count = $('#profile-following-count');
                count.text(parseInt(count.text()) + 1);
                setTimeout(() => { $(this).closest('div').fadeOut(); }, 1000);
            });
        }
    };
});