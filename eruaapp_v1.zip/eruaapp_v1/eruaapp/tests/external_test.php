<?php
/**
 * Test unitario para la clase local_eruaapp_external.
 *
 * @package local_eruaapp
 * @copyright 2024 Su Nombre/Organización
 * @license http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

use local_eruaapp\external\eruaapp_external;
use testing_external_api_testcase;
use context_system;

/**
 * Clase de test para los servicios externos de la App ERUA.
 * * Extiende testing_external_api_testcase para asegurar que las pruebas de API
 * se ejecuten en el contexto adecuado (sin una sesión de navegador real).
 */
class local_eruaapp_external_test extends testing_external_api_testcase {
    
    /** @var \core_user */
    protected $testuser;

    /** @var int ID del post de prueba. */
    protected $postid;

    /**
     * Configuración inicial antes de cada test.
     */
    protected function setUp(): void {
        global $DB;
        parent::setUp();
        
        // Crear un usuario de prueba (estudiante) que tendrá acceso.
        $this->testuser = $this->getDataGenerator()->create_user(['username' => 'testuser_erua']);

        // Crear una capacidad ficticia necesaria para el test de permisos.
        $this->setUpCapabilities('local/eruaapp:viewfeed', context_system::instance());

        // Insertar un post de prueba en la DB.
        $post = [
            'userid' => $this->testuser->id,
            'type' => 'status',
            'content' => 'Este es el primer post de prueba.',
            'timecreated' => time(),
            'timemodified' => time(),
        ];
        $this->postid = $DB->insert_record('local_erua_posts', (object)$post);
    }

    /**
     * Limpieza después de cada test.
     */
    protected function tearDown(): void {
        // La limpieza de usuarios/datos se maneja por testing_external_api_testcase y Moodle's Datagenerator.
        parent::tearDown();
    }

    // --------------------------------------------------------------------------
    // TESTS DE PERMISOS
    // --------------------------------------------------------------------------

    /**
     * Prueba que el acceso sea denegado si el usuario no tiene la capacidad de vista.
     */
    public function test_get_posts_permission_denied() {
        // Crear un usuario sin la capacidad 'local/eruaapp:viewfeed'.
        $denieduser = $this->getDataGenerator()->create_user(['username' => 'denieduser']);
        
        // Esperar una excepción de acceso denegado.
        $this->expectException(\moodle_exception::class);
        $this->expectExceptionMessage('Nocapabilitytosaythat');

        // Ejecutar la función como el usuario sin permisos.
        $this->setUser($denieduser);
        eruaapp_external::get_posts();
    }

    /**
     * Prueba que el acceso sea concedido cuando el usuario tiene la capacidad.
     */
    public function test_get_posts_permission_granted() {
        // Otorgar el permiso de vista al usuario de prueba.
        $this->grantCapability('local/eruaapp:viewfeed', context_system::instance(), $this->testuser->id);

        // Ejecutar la función como el usuario con permisos.
        $this->setUser($this->testuser);
        
        // La función debe ejecutarse sin errores.
        $posts = eruaapp_external::get_posts();
        $this->assertIsArray($posts);
        $this->assertCount(1, $posts);
    }

    // --------------------------------------------------------------------------
    // TESTS DE LÓGICA DE NEGOCIO
    // --------------------------------------------------------------------------

    /**
     * Prueba la recuperación de datos y la paginación.
     */
    public function test_get_posts_data_and_pagination() {
        global $DB;
        $this->grantCapability('local/eruaapp:viewfeed', context_system::instance(), $this->testuser->id);
        $this->setUser($this->testuser);

        // Insertar 5 posts adicionales.
        for ($i = 0; $i < 5; $i++) {
             $post = [
                'userid' => $this->testuser->id,
                'type' => 'status',
                'content' => "Post número $i.",
                'timecreated' => time() + $i, // Asegurar orden.
                'timemodified' => time() + $i,
            ];
            $DB->insert_record('local_erua_posts', (object)$post);
        }
        
        // Prueba 1: Sin skip, limit 3.
        $posts = eruaapp_external::get_posts(0, 3);
        $this->assertCount(3, $posts, 'Debe devolver solo 3 posts para el límite 3.');

        // Prueba 2: Con skip 3, limit 10.
        $posts = eruaapp_external::get_posts(3, 10);
        // Debería devolver 3 posts restantes (el post inicial + 5 nuevos = 6, 6 - 3 skip = 3).
        $this->assertCount(3, $posts, 'Debe devolver 3 posts restantes después del skip.');
    }
    
    /**
     * Prueba que el conteo de likes y la bandera 'liked' funcionen correctamente.
     */
    public function test_get_posts_likes_and_liked_flag() {
        global $DB;
        $this->grantCapability('local/eruaapp:viewfeed', context_system::instance(), $this->testuser->id);
        $this->setUser($this->testuser);

        // Crear un segundo usuario para el like.
        $likeruser = $this->getDataGenerator()->create_user(['username' => 'likeruser']);

        // Insertar un like del testuser (el que está ejecutando la función) al postid.
        $like1 = [
            'postid' => $this->postid,
            'userid' => $this->testuser->id,
            'timecreated' => time()
        ];
        $DB->insert_record('local_erua_likes', (object)$like1);
        
        // Insertar un like del likeruser al postid.
        $like2 = [
            'postid' => $this->postid,
            'userid' => $likeruser->id,
            'timecreated' => time()
        ];
        $DB->insert_record('local_erua_likes', (object)$like2);

        // Ejecutar la función como el testuser.
        $posts = eruaapp_external::get_posts(0, 1);
        $post = $posts[0];

        // 1. Verificar el conteo de likes (debe ser 2).
        $this->assertEquals(2, $post['numlikes'], 'El conteo total de likes debe ser 2.');

        // 2. Verificar la bandera 'liked' (debe ser true porque el testuser es el que dio like).
        $this->assertTrue($post['liked'], 'El post debe tener liked=true para el usuario actual.');
        
        // 3. Prueba de liked=false (Ejecutar la función como el likeruser).
        $this->setUser($likeruser);
        $posts_as_liker = eruaapp_external::get_posts(0, 1);
        $post_as_liker = $posts_as_liker[0];
        $this->assertTrue($post_as_liker['liked'], 'El post debe tener liked=true para el likeruser.');
        
        // 4. Prueba de liked=false (Crear un usuario que NO ha dado like y NO está en la DB).
        $unlikeruser = $this->getDataGenerator()->create_user(['username' => 'unlikeruser']);
        $this->setUser($unlikeruser);
        $posts_as_unliker = eruaapp_external::get_posts(0, 1);
        $post_as_unliker = $posts_as_unliker[0];
        $this->assertFalse($post_as_unliker['liked'], 'El post debe tener liked=false para un usuario que no dio like.');
    }
}