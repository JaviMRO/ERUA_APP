<?php
/**
 * Main entry point for ERUA App.
 */

require_once('../../config.php');

// 1. Seguridad básica
require_login();
$context = context_system::instance();
$PAGE->set_context($context);
$PAGE->set_url('/local/eruaapp/index.php');
$PAGE->set_title('ERUA App');
$PAGE->set_heading('ERUA App');

// 2. Configurar diseño para que ocupe toda la pantalla (sin bloques laterales si es posible)
$PAGE->set_pagelayout('standard'); 

// 3. Cargar nuestros estilos CSS y el módulo JS
$PAGE->requires->css('/local/eruaapp/styles.css');
$PAGE->requires->js_call_amd('local_eruaapp/main', 'init');

// 4. Renderizar la página
echo $OUTPUT->header();

// Renderizar la plantilla principal (app_layout.mustache)
echo $OUTPUT->render_from_template('local_eruaapp/app_layout', []);

echo $OUTPUT->footer();