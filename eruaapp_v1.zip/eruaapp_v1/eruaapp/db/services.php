<?php
/**
 * @package local_eruaapp
 * @copyright 2024 Su Nombre/Organización
 * @license http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

/**
 * Definición de los servicios web (Web Services) para local_eruaapp.
 * Los servicios web permiten la comunicación entre el cliente (JavaScript, aplicaciones móviles) 
 * y el servidor Moodle.
 */
$functions = array(
    // Función para obtener los posts del feed social.
    'local_eruaapp_get_posts' => array(
        'classname'   => 'local_eruaapp_external',
        'methodname'  => 'get_posts',
        'classpath'   => 'local/eruaapp/classes/external/eruaapp_external.php',
        'description' => 'Obtiene una lista paginada de posts para el feed social, incluyendo conteo de likes e información del autor.',
        'type'        => 'read',
        'ajax'        => true, // Accesible vía AJAX para el frontend de Moodle.
        
        // Define la capacidad Moodle requerida para ejecutar esta función.
        'capabilities' => 'local/eruaapp:viewfeed',
        
        // Parámetros.
        'params'      => array(
            'skip' => array(
                'type' => PARAM_INT,
                'description' => 'Número de posts a saltar (offset para paginación).',
                'required' => false,
                'default' => 0
            ),
            'limit' => array(
                'type' => PARAM_INT,
                'description' => 'Número máximo de posts a devolver.',
                'required' => false,
                'default' => 10
            )
        ),
        
        // Formato de la respuesta.
        'returns'     => array(
            'name' => 'posts',
            'type' => PARAM_RAW,
            'description' => 'Array de objetos de posts listos para ser renderizados por Mustache.',
            'allownull' => false,
            'structure' => 'local_eruaapp_external::get_posts_returns', // Enlaza con la definición de retorno estricta.
        )
    ),
);